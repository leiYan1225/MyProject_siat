package cn.sibat.gongAn

import java.sql.{Date, DriverManager, ResultSet, Timestamp}
import java.text.SimpleDateFormat

object Test extends App {
//  val conn_str = "jdbc:postgresql://190.176.32.8:5432/police_traffic"
////  classOf[org.postgresql.Driver]
//  // 使用上一句可能会有warning，因为这是一个表达式，可以换成下面的
//   Class.forName("org.postgresql.Driver").newInstance
//  val conn = DriverManager.getConnection(conn_str, "postgres", "postgres")
//
//  try {
//    // Configure to be Read Only
//    val statement = conn.createStatement(ResultSet.TYPE_FORWAR
  // D_ONLY, ResultSet.CONCUR_READ_ONLY)
//    // Execute Query
//    val rs = statement.executeQuery("SELECT gb_code FROM basic_device_info LIMIT 5")
//    // Iterate Over ResultSet
//    while (rs.next) {
//      println(rs.getString("gb_code"))
//    }
//  }
//  finally {
//    conn.close
//  }
  println(new Array[Int](96).+:("2017", "st").mkString(","))
//  val serverReceiveTime = "2018-06-20 06:00:00"
//  val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
//  val timeStamp = sdf.parse(serverReceiveTime).getTime
//
//  val time = sdf.format(new Date(1529445600L * 1000))
//  println((timeStamp, time))
}
