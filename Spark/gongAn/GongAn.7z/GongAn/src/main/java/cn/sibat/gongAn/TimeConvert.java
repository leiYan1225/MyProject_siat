package cn.sibat.gongAn;

import java.sql.Date;
import java.text.SimpleDateFormat;

public class TimeConvert {
    public static String stampToTime(Long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date(timestamp * 1000));
    }
    public static void main(String[] args) {
        Long timestamp = 1529424000L;
        System.out.println(stampToTime(timestamp));
    }
}
