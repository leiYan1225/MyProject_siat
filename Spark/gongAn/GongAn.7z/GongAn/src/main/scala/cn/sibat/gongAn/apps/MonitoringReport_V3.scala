package cn.sibat.gongAn.apps
import java.sql.Timestamp

import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{DataFrame, SparkSession}

import MonitoringReport_V1.{subtotal, readFromPostgresql, write2Mysql}

/**
  * 公安监督报表的第三个版本，所有的数据都有唯一标识即国标码gb_no
  */
//object MonitoringReport_V3 {
//
//  /**
//    * 处理所有设备数据的公共方法
//    * @param df 设备数据接收情况，(gb_id, num, flow)
//    * @param deviceType 设备类型
//    * @param deviceInfo 设备表
//    * @return 输出报表
//    */
//  def dealData(df: DataFrame, deviceType: String, deviceInfo: DataFrame, date: String): DataFrame = {
//    import df.sparkSession.implicits._
//
//    val dfMap = df.groupByKey(row => row.getAs[String]("gb_no")).mapGroups((key, iter) => {
//      var station_device_data_num = 0
//      var station_device_flow = 0.0
//      iter.toArray.foreach(row => {
//        station_device_data_num += row.getAs[Int]("num")
//        station_device_flow += row.getAs[Double]("flow")
//      })
//      (key, (station_device_data_num, station_device_flow))
//    }).collect().toMap
//
//    val bc = df.sparkSession.sparkContext.broadcast(dfMap)
//
//    val resultDf = deviceInfo.filter(col("device_type") === deviceType).select("line_name", "station_id", "station_name", "gb_no").distinct()
//      .map(row => {
//        val mac = row.getAs("gb_no")
//        val line_name = row.getAs[String]("line_name")
//        val station_id = row.getAs("station_id")
//        val station_name = row.getAs[String]("station_name")
//        val device_type = deviceType
//        val device_online_no = 0
//        val station_device_data_num = bc.value.getOrElse(mac, (0, 0.0))._1
//        val station_device_flow = bc.value.getOrElse(mac, (0, 0.0))._2.toString
//        val create_time = new Timestamp(System.currentTimeMillis())
//        MonitoringData(line_name, station_id, station_name, device_type, device_online_no, station_device_data_num, station_device_flow, create_time, date)
//      }).toDF().filter(col("station_device_data_num") =!= 0).groupByKey(row => row.getAs[String]("line_name") + "," + row.getAs[String]("station_name") + "," + row.getAs[String]("station_id") + "," + row.getAs[String]("device_type")).mapGroups((key, iter) => {
//      val records = iter.toArray
//      val Array(line_name, station_name, station_id, device_type): Array[String] = key.split(",")
//      var Tuple3(device_online_no, station_device_data_num, station_device_flow) = (0, 0, 0.0)
//      records.foreach(row => {
//        device_online_no += 1
//        station_device_data_num += row.getAs[Int]("station_device_data_num")
//        station_device_flow += row.getAs[String]("station_device_flow").toDouble
//      })
//      MonitoringData(line_name, station_id, station_name, device_type, device_online_no, station_device_data_num, station_device_flow.toString, new Timestamp(System.currentTimeMillis()), date)
//    }).toDF()
//
//    resultDf
//  }
//
//  def main(args: Array[String]): Unit = {
//    var dataPath = args(0) //GongAn
//    val url = args(1) //jdbc:mysql://190.176.32.8:3306/shipin
//    val deviceinfo = args(2) //deviceinfo
//    val tableToWrite = args(3) //data_monitoring_report
//    val user = args(4) //beidou
//    val password = args(5) //beidou123
//    val device_type = args(6)
//    val date = args(7) //current date
//
//    val spark = SparkSession.builder()
//      .getOrCreate()
//    spark.sparkContext.setLogLevel("ERROR")
//    import spark.implicits._
//
//    val deviceInfoTable = readFromMysql(spark, url, deviceinfo, user, password)
//
//    val resultDf = device_type match {
//
//      case "AP" =>
//        dataPath = dataPath + "ap_point/" + date //add date
//        val ap = spark.read.parquet(dataPath).groupByKey(row => row.getAs[String]("gb_no")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("gb_no", "num", "flow")
//        dealData(ap, device_type, deviceInfoTable, date)
//
//      case "sensorDoor" =>
//        val dataPathForFace = dataPath + "sensordoor_face/" + date
//        val dataPathForHeartbeat = dataPath + "sensordoor_heartbeat/" + date
//        val dataPathForIdCard = dataPath + "sensordoor_idcard/" + date
//
//        val face = spark.read.parquet(dataPathForFace).groupByKey(row => row.getAs[String]("gb_no")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("gb_no", "num", "flow")
//        val heartbeat = spark.read.parquet(dataPathForHeartbeat).groupByKey(row => row.getAs[String]("gb_no")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("gb_no", "num", "flow")
//        val idCard = spark.read.parquet(dataPathForIdCard).groupByKey(row => row.getAs[String]("gb_no")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("gb_no", "num", "flow")
//
//        //把三种数据合并到同一个设备下汇总设备接收数据条数和设备接收的数据流量大小
//        val sensorDoor = face.union(heartbeat).union(idCard)
//        dealData(sensorDoor, device_type, deviceInfoTable, date)
//
//      case "LTE" =>
//        val dataPathForImsi = dataPath + "ty_imsi/" + date
//        val dataPathForStatus = dataPath + "ty_status/" + date
//
//        val imsi = spark.read.parquet(dataPathForImsi).groupByKey(row => row.getAs[String]("gb_no")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("gb_no", "num", "flow")
//        val status = spark.read.parquet(dataPathForStatus).groupByKey(row => row.getAs[String]("gb_no")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("gb_no", "num", "flow")
//
//        val LTE = imsi.union(status)
//        dealData(LTE, device_type, deviceInfoTable, date)
//
//      case "wifi" =>
//        val dataPathForDevice = dataPath + "rzx_device/"  + date
//        val dataPathForFeature = dataPath + "rzx_feature/" + date
//
//        val device = spark.read.parquet(dataPathForDevice).groupByKey(row => row.getAs[String]("gb_no")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("gb_no", "num", "flow")
//        val feature = spark.read.parquet(dataPathForFeature).groupByKey(row => row.getAs[String]("gb_no")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("gb_no", "num", "flow")
//
//        val wifi = device.union(feature)
//        dealData(wifi, device_type, deviceInfoTable, date)
//    }
//
//    write2Mysql(resultDf, url, tableToWrite, user, password)
//    resultDf.map(_.mkString(",")).write.mode("overwrite").text("motoringData/" + device_type + "/" + date)
//  }
//}