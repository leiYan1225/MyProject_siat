package cn.sibat.gongAn.apps

import java.sql.Timestamp
import java.util.Properties

import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import cn.sibat.gongAn.ConnectionPool

/**
  * 版本一：直接从deviceinfo表里面获取匹配的数据
  */
object MonitoringReport_V1 {
  /**
    * 从数据库中读取静态信息表
    * @param sparkSession spark
    * @param url utl
    * @param table table
    * @param user user
    * @param password password
    * @return staticTable
    */
  def readFromPostgresql(sparkSession: SparkSession, url: String, table: String, user: String, password: String): DataFrame = {
    val prop = new Properties()
    prop.setProperty("user", user)
    prop.setProperty("password", password)
    prop.setProperty("driver","com.postgresql.jdbc.Driver")

    val staticTable = sparkSession.read.jdbc(url, table, prop)
    staticTable
  }

  /**
    * 把df数据写进mysql数据库
    *
    * @param df row的格式必须与表的结构一致
    */
  def write2Mysql(df: DataFrame, url: String, table: String, user: String, password: String): Unit = {
    val prop = new Properties()
    prop.setProperty("user", user)
    prop.setProperty("password", password)
    prop.put("driver","com.mysql.jdbc.Driver")
    df.write.mode("append").jdbc(url, table, prop)
  }

  def write2Mysql_V1(df: DataFrame, url: String, user: String, password: String): Unit = {

    df.foreach(row => {
      @transient var conn = ConnectionPool.getConnection(url, user, password)
        val sql = "insert into data_monitoring_report(line_name, station_id, station_name, device_type, device_online_no, station_device_data_num, station_device_flow, create_time, monitor_date) values (" +
          row.getAs[String]("line_name") + "," +
          row.getAs[String]("station_id") + "," +
          row.getAs[String]("station_name") + "," +
          row.getAs[String]("device_type") + "," +
          row.getAs[Int]("device_online_no") + "," +
          row.getAs[Int]("station_device_data_num") + "," +
          row.getAs[String]("station_device_flow") + "," +
          row.getAs[Timestamp]("create_time") + "," +
          row.getAs[String]("monitor_date") + ")"
        var stmt = conn.createStatement
        var flag = stmt.executeUpdate(sql)

        while (flag == 0) {
          conn = ConnectionPool.getConnection(url, user, password)
          stmt = conn.createStatement
          flag = stmt.executeUpdate(sql)
        }
      ConnectionPool.returnConnection(conn)
    })
  }

  /**
    * 分类汇总每个站点的设备接收数据条数和接收的流量大小（kb）方法
    * @param key key 有些mac是-分割的
    * @param iter 分组内容
    * @return 组内统计的结果
    */
  def subtotal(key: String, iter: Iterator[Row]): (String, Int, Double) = {
    val records = iter.toArray
    val station_device_data_num = records.length
    var station_device_flow = 0
    records.foreach(row => {
      val line = row.mkString("")
      station_device_flow += line.length
    })
    (key.split("-").mkString(""), station_device_data_num, station_device_flow / 1024.0)
  }

//  def main(args: Array[String]): Unit = {
//    var dataPath = args(0) //GongAn
//    val cvsPath = args(1) //sum.csv
//    val url = args(2) //jdbc:mysql://190.176.32.8:3306/shipin
//    val tableToRead = args(3) //deviceinfo
//    val tableToWrite = args(4) //data_monitoring_report
//    val user = args(5) //beidou
//    val password = args(6) //beidou123
//    val device_type = args(7)
//    val date = args(8) //报表日期
//
//    val spark = SparkSession.builder()
//      .getOrCreate()
//    spark.sparkContext.setLogLevel("ERROR")
//    import spark.implicits._
//
//    val staticTable = readFromMysql(spark, url, tableToRead, user, password)
//
//    if (device_type == "AP") {
//
//      dataPath = dataPath + "ap_point/" + date //add date
//      val ap = spark.read.parquet(dataPath)
//      val APMap = ap.groupByKey(row => row.getAs[String]("bid")).mapGroups(subtotal).collect().toMap
//
//      val bc = spark.sparkContext.broadcast(APMap)
//
//      val APDf = staticTable.filter(col("device_type") === "AP").select("line_name", "station_id", "station_name").distinct()
//        .map(row => {
//          val line_name = row.getAs[String]("line_name")
//          val station_id = row.getAs[String]("station_id")
//          val station_name = row.getAs[String]("station_name")
//          val device_type = "AP"
//          val device_online_no = 0 //从其他表里读到的在线设备数据，广播进来
//          val station_device_data_num = bc.value.getOrElse(station_id, (0, 0.0))._1
//          val station_device_flow = bc.value.getOrElse(station_id, (0, 0.0))._2.toString
//          val create_time = new Timestamp(System.currentTimeMillis())
//          MonitoringData(line_name, station_id, station_name, device_type, device_online_no, station_device_data_num, station_device_flow, create_time, date)
//        }).toDF().filter(col("station_device_data_num") =!= 0)
//      write2Mysql(APDf, url, tableToWrite, user, password)
//      APDf.map(_.mkString(",")).write.mode("overwrite").text("motoringData/AP/" + date)
//
//    } else if (device_type == "sensorDoor") {
//
//      val dataPathForFace = dataPath + "sensordoor_face/" + date
//      val dataPathForHeartbeat = dataPath + "sensordoor_heartbeat/" + date
//      val dataPathForIdcard = dataPath + "sensordoor_idcard/" + date
//
//      val face = spark.read.parquet(dataPathForFace).groupByKey(row => row.getAs[String]("mac")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("mac", "num", "flow")
//      val heartbeat = spark.read.parquet(dataPathForHeartbeat).groupByKey(row => row.getAs[String]("mac")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("mac", "num", "flow")
//      val idcard = spark.read.parquet(dataPathForIdcard).groupByKey(row => row.getAs[String]("mac")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("mac", "num", "flow")
//
//      //把三种数据合并到同一个设备下汇总
//      val sensorDoor = face.union(heartbeat).union(idcard).groupByKey(row => row.getAs[String]("mac")).mapGroups((key, iter) => {
//        var station_device_data_num = 0
//        var station_device_flow = 0.0
//        iter.toArray.foreach(row => {
//          station_device_data_num += row.getAs[Int]("num")
//          station_device_flow += row.getAs[Double]("flow")
//        })
//        (key, (station_device_data_num, station_device_flow))
//      }).collect().toMap
//
//      val bc = spark.sparkContext.broadcast(sensorDoor)
//
//      val sensorDoorDf = staticTable.filter(col("device_type") === "感知门").select("mac_no", "line_name", "station_id", "station_name").distinct()
//        .map(row => {
//          val mac = row.getAs[String]("mac_no").split(":").mkString("")
//          val line_name = row.getAs[String]("line_name")
//          val station_id = row.getAs[String]("station_id")
//          val station_name = row.getAs[String]("station_name")
//          val device_type = "感知门"
//          val device_online_no = 0 //在线设备数量初始化为0
//          val station_device_data_num = bc.value.getOrElse(mac, (0, 0.0))._1
//          val station_device_flow = bc.value.getOrElse(mac, (0, 0.0))._2.toString
//          val create_time = new Timestamp(System.currentTimeMillis())
//          MonitoringData(line_name, station_id, station_name, device_type, device_online_no, station_device_data_num, station_device_flow, create_time, date)
//        }).toDF().filter(col("station_device_data_num") =!= 0).groupByKey(row => row.getAs[String]("line_name") + "," + row.getAs[String]("station_id") + "," + row.getAs[String]("station_name") + "," + row.getAs[String]("device_type")).mapGroups((key, iter) => {
//        val records = iter.toArray
//        val Array(line_name, station_id, station_name, device_type) = key.split(",")
//        var Tuple3(device_online_no, station_device_data_num, station_device_flow) = (0, 0, 0.0)
//        records.foreach(row => {
//          device_online_no += 1
//          station_device_data_num += row.getAs[Int]("station_device_data_num")
//          station_device_flow += row.getAs[String]("station_device_flow").toDouble
//        })
//        MonitoringData(line_name, station_id, station_name, device_type, device_online_no, station_device_data_num, station_device_flow.toString, new Timestamp(System.currentTimeMillis()), date)
//      }).toDF()
//      write2Mysql(sensorDoorDf, url, tableToWrite, user, password)
//      sensorDoorDf.map(_.mkString(",")).write.mode("overwrite").text("motoringData/sensorDoor/" + date)
//
//    } else if (device_type == "LTE") {
//
//      val deviceIdToSite = spark.read.option("encoding", "GB2312").option("header", "true").format("csv").load(cvsPath).map(row => {
//        val deviceId = row.getAs[String]("设备ID")
//        val lineName = row.getAs[String]("线路") match {
//          case "一号线" => "1号线"
//          case "二号线" => "2号线"
//          case "三号线" => "3号线"
//          case "四号线" => "4号线"
//          case "五号线" => "5号线"
//          case "七号线" => "7号线"
//          case "九号线" => "9号线"
//          case "十一号线" => "11号线"
//        }
//        val stationNameWithLine = row.getAs[String]("站点名").substring(0, row.getAs[String]("站点名").length - 1) + "," + lineName //将站点名中最后一个编号去除
//        (deviceId, stationNameWithLine)
//      }).collect().toMap
//
//      val siteBc = spark.sparkContext.broadcast(deviceIdToSite)
//
//      val dataPathForImsi = dataPath + "ty_imsi/" + date
//      val dataPathForStatus = dataPath + "ty_status/" + date
//
//      val imsi = spark.read.parquet(dataPathForImsi).groupByKey(row => row.getAs[String]("deviceId")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("deviceId", "num", "flow")
//      val status = spark.read.parquet(dataPathForStatus).groupByKey(row => row.getAs[String]("deviceId")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("deviceId", "num", "flow")
//
//      val LTE = imsi.union(status).groupByKey(row => row.getAs[String]("deviceId")).mapGroups((key, iter) => {
//        var station_device_data_num = 0
//        var station_device_flow = 0.0
//        iter.toArray.foreach(row => {
//          station_device_data_num += row.getAs[Int]("num")
//          station_device_flow += row.getAs[Double]("flow")
//        })
//        (key, siteBc.value.getOrElse(key, "null"), station_device_data_num, station_device_flow) //存在多设备对应于一个站点
//      }).groupByKey(_._2).mapGroups((stationName, stationData) => {
//        var (device_online_no, station_device_data_num, station_device_flow) = (0, 0, 0.0)
//        stationData.foreach(tuple => {
//          device_online_no += 1
//          station_device_data_num += tuple._3
//          station_device_flow += tuple._4
//        })
//        (stationName, (device_online_no, station_device_data_num, station_device_flow))
//      }).collect().toMap
//
//      val bc = spark.sparkContext.broadcast(LTE)
//
//      val LTEDf = staticTable.filter(col("device_type") === "LTE").select("line_name", "station_id", "station_name").distinct()
//        .map(row => {
//          val line_name = row.getAs[String]("line_name")
//          val station_id = row.getAs[String]("station_id")
//          val station_name = row.getAs[String]("station_name")
//          val device_type = "LTE"
//          val device_online_no = bc.value.getOrElse(station_name + "," + line_name, (0, 0, 0.0))._1
//          val station_device_data_num = bc.value.getOrElse(station_name + "," + line_name, (0, 0, 0.0))._2
//          val station_device_flow = bc.value.getOrElse(station_name + "," + line_name, (0, 0, 0.0))._3.toString
//          val create_time = new Timestamp(System.currentTimeMillis())
//          MonitoringData(line_name, station_id, station_name, device_type, device_online_no, station_device_data_num, station_device_flow, create_time, date)
//        }).toDF().filter(col("station_device_data_num") =!= 0)
//      write2Mysql(LTEDf, url, tableToWrite, user, password)
//      LTEDf.map(_.mkString(",")).write.mode("overwrite").text("motoringData/LTE/" + date)
//
//    } else if (device_type == "wifi") {
//
//      val dataPathForDevice = dataPath + "rzx_device/"  + date
//      val dataPathForFeature = dataPath + "rzx_feature/" + date
//
//      val deviceDf = spark.read.parquet(dataPathForDevice)
//      val deviceTable = deviceDf.map(row => (row.getAs[String]("equipmentnum"), row.getAs[String]("mac").split("-").mkString(""))).distinct().collect().toMap
//      val deviceBc = spark.sparkContext.broadcast(deviceTable)
//
//      val device = deviceDf.groupByKey(row => row.getAs[String]("mac")).mapGroups(subtotal).map(tuple => (tuple._1.split("-").mkString(""), tuple._2._1, tuple._2._2)).toDF("mac", "num", "flow")
//      val feature = spark.read.parquet(dataPathForFeature).groupByKey(row => row.getAs[String]("devicenum")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("devicenum", "num", "flow")
//        .map(row => {
//          val devicenum = row.getAs[String]("devicenum")
//          val mac = deviceBc.value.getOrElse(devicenum, "null")
//          val num = row.getAs[Int]("num")
//          val flow = row.getAs[Double]("flow")
//          (mac, num, flow)
//        }).toDF("mac", "num", "flow")
//      val wifi = device.union(feature).groupByKey(row => row.getAs[String]("mac")).mapGroups((key, iter) => {
//        var station_device_data_num = 0
//        var station_device_flow = 0.0
//        iter.toArray.foreach(row => {
//          station_device_data_num += row.getAs[Int]("num")
//          station_device_flow += row.getAs[Double]("flow")
//        })
//        (key, (station_device_data_num, station_device_flow))
//      }).collect().toMap
//
//      val bc = spark.sparkContext.broadcast(wifi)
//
//      val wifiDf = staticTable.filter(col("device_type") === "WIFI").select("mac_no", "line_name", "station_id", "station_name").distinct()
//        .map(row => {
//          val mac = row.getAs[String]("mac_no").split(":").mkString("")
//          val line_name = row.getAs[String]("line_name")
//          val station_id = row.getAs[String]("station_id")
//          val station_name = row.getAs[String]("station_name")
//          val device_type = "WIFI"
//          val device_online_no = 0 //从其他表里读到的在线设备数据，广播进来
//          val station_device_data_num = bc.value.getOrElse(mac, (0, 0.0))._1
//          val station_device_flow = bc.value.getOrElse(mac, (0, 0.0))._2.toString
//          val create_time = new Timestamp(System.currentTimeMillis())
//          MonitoringData(line_name, station_id, station_name, device_type, device_online_no, station_device_data_num, station_device_flow, create_time, date)
//        }).toDF().filter(col("station_device_data_num") =!= 0).groupByKey(row => row.getAs[String]("line_name") + "," + row.getAs[String]("station_id") + "," + row.getAs[String]("station_name") + "," + row.getAs[String]("device_type")).mapGroups((key, iter) => {
//        val records = iter.toArray
//        val Array(line_name, station_id, station_name, device_type) = key.split(",")
//        var Tuple3(device_online_no, station_device_data_num, station_device_flow) = (0, 0, 0.0)
//        records.foreach(row => {
//          device_online_no += 1
//          station_device_data_num += row.getAs[Int]("station_device_data_num")
//          station_device_flow += row.getAs[String]("station_device_flow").toDouble
//        })
//        MonitoringData(line_name, station_id, station_name, device_type, device_online_no, station_device_data_num, station_device_flow.toString, new Timestamp(System.currentTimeMillis()), date)
//      }).toDF()
//      write2Mysql(wifiDf, url, tableToWrite, user, password)
//      wifiDf.map(_.mkString(",")).write.mode("overwrite").text("motoringData/wifi/" + date)
//
//    }
//  }
}

/**
  * 监控报表结构
  * @param line_name 线路名称
  * @param station_id 站点id
  * @param station_name 站点名称
  * @param device_type 设备类型
  * @param device_online_no 在线设备数量
  * @param station_device_data_num 站点设备数据采集总条数
  * @param station_device_flow 站点设备数据采集量（M）
  * @param create_time 创建时间
  * @param monitor_date 监控报表日期
  */
case class MonitoringData(line_name: String, station_id: String, station_name: String, device_type: String, device_online_no: Int, station_device_data_num: Int, station_device_flow: String, create_time: Timestamp, monitor_date: String)

/**
  * 设备接收的数据
  * @param deviceId device_id or mac
  * @param station_device_data_num 站点设备数据采集总条数
  * @param station_device_flow 站点设备数据采集量
  */
case class DeviceData(deviceId: String, station_device_data_num: Int, station_device_flow: Double)