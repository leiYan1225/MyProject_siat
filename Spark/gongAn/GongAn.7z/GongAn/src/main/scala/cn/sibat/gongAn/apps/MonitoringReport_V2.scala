package cn.sibat.gongAn.apps

import java.sql.Timestamp

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col

import MonitoringReport_V1.{subtotal, readFromPostgresql, write2Mysql}

/**
  * 公安地铁的监控报表的第二个版本，使用小猪猪的私库数据进行匹配
  * Created by wing on 2018/5/3.
  */
//object MonitoringReport_V2{
//
//  def main(args: Array[String]): Unit = {
//    var dataPath = args(0) //GongAn
//    val url = args(1) //jdbc:mysql://190.176.32.8:3306/shipin
//    val deviceinfo = args(2) //deviceinfo
//    val device_new_info = args(3) //小猪猪的匹配表，用于匹配AP以外的其他三类数据
//    val tableToWrite = args(4) //data_monitoring_report
//    val user = args(5) //beidou
//    val password = args(6) //beidou123
//    val device_type = args(7)
//    val date = args(8) //current date
//
//    val spark = SparkSession.builder()
//      .getOrCreate()
//    spark.sparkContext.setLogLevel("ERROR")
//    import spark.implicits._
//
//    val deviceInfoTable = readFromMysql(spark, url, deviceinfo, user, password)
//    val deviceNewInfoTable = readFromMysql(spark, url, device_new_info, user, password)
//
//    //AP数据是没有mac或者设备ID来识别出设备的，只有一个bid字段可以知道数据来源于哪个站点，因此这里统计的是AP数据在各个站点接收的数据条数和数据流量
//    if (device_type == "AP") {
//
//      dataPath = dataPath + "ap_point/" + date //add date
//      val ap = spark.read.parquet(dataPath)
//      val APMap = ap.groupByKey(row => row.getAs[String]("bid")).mapGroups(subtotal).collect().toMap
//
//      val bc = spark.sparkContext.broadcast(APMap)
//
//      val APDf = deviceInfoTable.filter(col("device_type") === "AP").select("line_name", "station_id", "station_name").distinct()
//        .map(row => {
//          val line_name = row.getAs[String]("line_name")
//          val station_id = row.getAs[String]("station_id")
//          val station_name = row.getAs[String]("station_name")
//          val device_type = "AP"
//          val device_online_no = 0 //AP的在线设备数量无法识别
//          val station_device_data_num = bc.value.getOrElse(station_id, (0, 0.0))._1
//          val station_device_flow = bc.value.getOrElse(station_id, (0, 0.0))._2.toString
//          val create_time = new Timestamp(System.currentTimeMillis())
//          MonitoringData(line_name, station_id, station_name, device_type, device_online_no, station_device_data_num, station_device_flow, create_time, date)
//        }).toDF().filter(col("station_device_data_num") =!= 0)
//      write2Mysql(APDf, url, tableToWrite, user, password)
//      APDf.map(_.mkString(",")).write.mode("overwrite").text("motoringData/AP/" + date)
//
//    }
//    //感知门数据根据设备id来识别每个设备
//    else if (device_type == "sensorDoor") {
//
//      val dataPathForFace = dataPath + "sensordoor_face/" + date
//      val dataPathForHeartbeat = dataPath + "sensordoor_heartbeat/" + date
//      val dataPathForIdCard = dataPath + "sensordoor_idcard/" + date
//
//      val face = spark.read.parquet(dataPathForFace).groupByKey(row => row.getAs[String]("mac")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("mac", "num", "flow")
//      val heartbeat = spark.read.parquet(dataPathForHeartbeat).groupByKey(row => row.getAs[String]("mac")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("mac", "num", "flow")
//      val idCard = spark.read.parquet(dataPathForIdCard).groupByKey(row => row.getAs[String]("mac")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("mac", "num", "flow")
//
//      //把三种数据合并到同一个设备下汇总设备接收数据条数和设备接收的数据流量大小
//      val sensorDoor = face.union(heartbeat).union(idCard).groupByKey(row => row.getAs[String]("mac")).mapGroups((key, iter) => {
//        var station_device_data_num = 0
//        var station_device_flow = 0.0
//        iter.toArray.foreach(row => {
//          station_device_data_num += row.getAs[Int]("num")
//          station_device_flow += row.getAs[Double]("flow")
//        })
//        (key, (station_device_data_num, station_device_flow))
//      }).collect().toMap
////      println(sensorDoor.size)
//
//      val bc = spark.sparkContext.broadcast(sensorDoor)
//
//      val sensorDoorDf = deviceNewInfoTable
//        .map(row => {
//          val mac = row.getAs[String]("key_id")
//          val line_name = row.getAs[String]("line_name")
//          val station_name = row.getAs[String]("station_name")
//          val device_type = "感知门"
//          val device_online_no = 0 //在线设备数量初始化为0
//          val station_device_data_num = bc.value.getOrElse(mac, (0, 0.0))._1
//          val station_device_flow = bc.value.getOrElse(mac, (0, 0.0))._2.toString
//          val create_time = new Timestamp(System.currentTimeMillis())
//          MonitoringData(line_name, null, station_name, device_type, device_online_no, station_device_data_num, station_device_flow, create_time, date)
//        }).toDF().filter(col("station_device_data_num") =!= 0).groupByKey(row => row.getAs[String]("line_name") + "," + row.getAs[String]("station_name") + "," + row.getAs[String]("device_type")).mapGroups((key, iter) => {
//        val records = iter.toArray
//        val Array(line_name, station_name, device_type) = key.split(",")
//        var Tuple3(device_online_no, station_device_data_num, station_device_flow) = (0, 0, 0.0)
//        records.foreach(row => {
//          device_online_no += 1
//          station_device_data_num += row.getAs[Int]("station_device_data_num")
//          station_device_flow += row.getAs[String]("station_device_flow").toDouble
//        })
//        MonitoringData(line_name, station_id = null, station_name, device_type, device_online_no, station_device_data_num, station_device_flow.toString, new Timestamp(System.currentTimeMillis()), date)
//      }).toDF()
//      println(sensorDoor.size)
//      write2Mysql(sensorDoorDf, url, tableToWrite, user, password)
//      sensorDoorDf.map(_.mkString(",")).write.mode("overwrite").text("motoringData/sensorDoor/" + date)
//
//    }
//    //LTE的数据根据设备id来统计设备数据
//    else if (device_type == "LTE") {
//
//      val dataPathForImsi = dataPath + "ty_imsi/" + date
//      val dataPathForStatus = dataPath + "ty_status/" + date
//
//      val imsi = spark.read.parquet(dataPathForImsi).groupByKey(row => row.getAs[String]("deviceId")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("deviceId", "num", "flow")
//      val status = spark.read.parquet(dataPathForStatus).groupByKey(row => row.getAs[String]("deviceId")).mapGroups(subtotal).map(tuple => (tuple._1, tuple._2._1, tuple._2._2)).toDF("deviceId", "num", "flow")
//
//      val LTE = imsi.union(status).groupByKey(row => row.getAs[String]("deviceId")).mapGroups((key, iter) => {
//        var station_device_data_num = 0
//        var station_device_flow = 0.0
//        iter.toArray.foreach(row => {
//          station_device_data_num += row.getAs[Int]("num")
//          station_device_flow += row.getAs[Double]("flow")
//        })
//        (key, (station_device_data_num, station_device_flow))
//      }).collect().toMap
//      println(LTE.size)
//
//      val bc = spark.sparkContext.broadcast(LTE)
//
//      val LTEDf = deviceNewInfoTable
//        .map(row => {
//          val deviceId = row.getAs[String]("key_id")
//          val line_name = row.getAs[String]("line_name")
//          val station_name = row.getAs[String]("station_name")
//          val device_type = "LTE"
//          val device_online_no = 0 //在线设备数量初始化为0
//          val station_device_data_num = bc.value.getOrElse(deviceId, (0, 0.0))._1
//          val station_device_flow = bc.value.getOrElse(deviceId, (0, 0.0))._2.toString
//          val create_time = new Timestamp(System.currentTimeMillis())
//          MonitoringData(line_name, null, station_name, device_type, device_online_no, station_device_data_num, station_device_flow, create_time, date)
//        }).toDF().filter(col("station_device_data_num") =!= 0).groupByKey(row => row.getAs[String]("line_name") + "," + row.getAs[String]("station_name") + "," + row.getAs[String]("device_type")).mapGroups((key, iter) => {
//        val records = iter.toArray
//        val Array(line_name, station_name, device_type) = key.split(",")
//        var Tuple3(device_online_no, station_device_data_num, station_device_flow) = (0, 0, 0.0)
//        records.foreach(row => {
//          device_online_no += 1
//          station_device_data_num += row.getAs[Int]("station_device_data_num")
//          station_device_flow += row.getAs[String]("station_device_flow").toDouble
//        })
//        MonitoringData(line_name, station_id = null, station_name, device_type, device_online_no, station_device_data_num, station_device_flow.toString, new Timestamp(System.currentTimeMillis()), date)
//      }).toDF()
//      write2Mysql(LTEDf, url, tableToWrite, user, password)
//      LTEDf.map(_.mkString(",")).write.mode("overwrite").text("motoringData/LTE/" + date)
//
//    } else if (device_type == "wifi") {
//
//      val dataPathForDevice = dataPath + "rzx_device/"  + date
//      val dataPathForFeature = dataPath + "rzx_feature/" + date
//
//      val device = spark.read.parquet(dataPathForDevice).groupByKey(row => row.getAs[String]("mac")).mapGroups(subtotal).map(tuple => (tuple._1.split("-").mkString(""), tuple._2._1, tuple._2._2)).toDF("mac", "num", "flow")
//      val feature = spark.read.parquet(dataPathForFeature).groupByKey(row => row.getAs[String]("devicenum")).mapGroups(subtotal).map(tuple => (tuple._1.substring(9), tuple._2._1, tuple._2._2)).toDF("mac", "num", "flow")
//
//      val wifi = device.union(feature).groupByKey(row => row.getAs[String]("mac")).mapGroups((key, iter) => {
//        var station_device_data_num = 0
//        var station_device_flow = 0.0
//        iter.toArray.foreach(row => {
//          station_device_data_num += row.getAs[Int]("num")
//          station_device_flow += row.getAs[Double]("flow")
//        })
//        (key, (station_device_data_num, station_device_flow))
//      }).collect().toMap
//      println(wifi.size)
//
//      val bc = spark.sparkContext.broadcast(wifi)
//
//      val wifiDf = deviceNewInfoTable
//        .map(row => {
//          val mac = row.getAs[String]("key_id")
//          val line_name = row.getAs[String]("line_name")
//          val station_id = null
//          val station_name = row.getAs[String]("station_name")
//          val device_type = "WIFI"
//          val device_online_no = 0 //从其他表里读到的在线设备数据，广播进来
//          val station_device_data_num = bc.value.getOrElse(mac, (0, 0.0))._1
//          val station_device_flow = bc.value.getOrElse(mac, (0, 0.0))._2.toString
//          val create_time = new Timestamp(System.currentTimeMillis())
//          MonitoringData(line_name, station_id, station_name, device_type, device_online_no, station_device_data_num, station_device_flow, create_time, date)
//        }).toDF().filter(col("station_device_data_num") =!= 0).groupByKey(row => row.getAs[String]("line_name") + "," + row.getAs[String]("station_name") + "," + row.getAs[String]("device_type")).mapGroups((key, iter) => {
//        val records = iter.toArray
//        val Array(line_name, station_name, device_type) = key.split(",")
//        var Tuple3(device_online_no, station_device_data_num, station_device_flow) = (0, 0, 0.0)
//        records.foreach(row => {
//          device_online_no += 1
//          station_device_data_num += row.getAs[Int]("station_device_data_num")
//          station_device_flow += row.getAs[String]("station_device_flow").toDouble
//        })
//        MonitoringData(line_name, null, station_name, device_type, device_online_no, station_device_data_num, station_device_flow.toString, new Timestamp(System.currentTimeMillis()), date)
//      }).toDF()
//      write2Mysql(wifiDf, url, tableToWrite, user, password)
//      wifiDf.map(_.mkString(",")).write.mode("overwrite").text("motoringData/wifi/" + date)
//
//    }
//
//  }
//}